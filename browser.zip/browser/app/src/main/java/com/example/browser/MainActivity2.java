package com.example.browser;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private WebView newWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        newWebView = findViewById(R.id.newWebView);
        newWebView.setWebViewClient(new WebViewClient());
        newWebView.getSettings().setJavaScriptEnabled(true);


        newWebView.loadUrl("https://www.google.com");
    }
}
