package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etDisplay;
    StringBuilder input = new StringBuilder();
    double operand1 = Double.NaN, operand2;
    char currentOp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etDisplay = findViewById(R.id.etDisplay);

        // همه دکمه‌ها را ثبت می‌کنیم
        int[] ids = {
                R.id.btnClear, R.id.btnPercent, R.id.btnBack, R.id.btnDivide,
                R.id.btn7, R.id.btn8, R.id.btn9, R.id.btnMultiply,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btnSubtract,
                R.id.btn1, R.id.btn2, R.id.btn3, R.id.btnAdd,
                R.id.btn0, R.id.btnDot, R.id.btnEqual
        };
        for (int id : ids) {
            findViewById(id).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        // پاک‌کردن
        if (id == R.id.btnClear) {
            input.setLength(0);
            operand1 = Double.NaN;
            currentOp = ' ';
            etDisplay.setText("");
            return;
        }
        // درصد
        else if (id == R.id.btnPercent) {
            if (input.length() > 0) {
                try {
                    double val = Double.parseDouble(input.toString());
                    val = val / 100.0;
                    input.setLength(0);
                    input.append(val);
                    etDisplay.setText(input.toString());
                } catch (NumberFormatException e) { }
            }
            return;
        }
        // backspace
        else if (id == R.id.btnBack) {
            if (input.length() > 0) {
                input.deleteCharAt(input.length() - 1);
                etDisplay.setText(input.toString());
            }
            return;
        }
        // مساوی
        else if (id == R.id.btnEqual) {
            compute();
            currentOp = ' ';
            return;
        }

        // اعداد و نقطه
        if (id == R.id.btnDot) {
            if (!input.toString().contains(".")) input.append(".");
        }
        else if (id >= R.id.btn0 && id <= R.id.btn9) {
            // تشخیص عدد از روی شناسه
            char digit = (char) ('0' + (id - R.id.btn0));
            input.append(digit);
        }
        // عملگرها
        else if (id == R.id.btnAdd)      setOp('+');
        else if (id == R.id.btnSubtract) setOp('-');
        else if (id == R.id.btnMultiply) setOp('*');
        else if (id == R.id.btnDivide)   setOp('/');

        etDisplay.setText(input.toString());
    }

    private void setOp(char op) {
        if (!Double.isNaN(operand1)) {
            compute();
        } else {
            try {
                operand1 = Double.parseDouble(input.toString());
            } catch (Exception e) {
                operand1 = 0;
            }
        }
        currentOp = op;
        input.setLength(0);
    }

    private void compute() {
        try {
            operand2 = Double.parseDouble(input.toString());
        } catch (Exception e) {
            operand2 = operand1;
        }
        if (!Double.isNaN(operand1)) {
            switch (currentOp) {
                case '+': operand1 += operand2; break;
                case '-': operand1 -= operand2; break;
                case '*': operand1 *= operand2; break;
                case '/':
                    if (operand2 != 0) operand1 /= operand2;
                    break;
            }
            input.setLength(0);
            input.append(operand1);
            etDisplay.setText(input.toString());
        }
    }
}
