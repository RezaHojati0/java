package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etNum1, etNum2;
    Button btnAdd, btnSubtract, btnMultiply, btnDivide;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        btnAdd = findViewById(R.id.btnAdd);
        btnSubtract = findViewById(R.id.btnSubtract);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        tvResult = findViewById(R.id.tvResult);


        btnAdd.setOnClickListener(this);
        btnSubtract.setOnClickListener(this);
        btnMultiply.setOnClickListener(this);
        btnDivide.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        double num1, num2, result = 0;

        
        try {
            num1 = Double.parseDouble(etNum1.getText().toString());
            num2 = Double.parseDouble(etNum2.getText().toString());
        } catch (NumberFormatException e) {
            tvResult.setText("لطفاً اعداد معتبر وارد کنید");
            return;
        }


        int id = v.getId();
        if (id == R.id.btnAdd) {
            result = num1 + num2;
        } else if (id == R.id.btnSubtract) {
            result = num1 - num2;
        } else if (id == R.id.btnMultiply) {
            result = num1 * num2;
        } else if (id == R.id.btnDivide) {
            if (num2 == 0) {
                tvResult.setText("تقسیم بر صفر مجاز نیست");
                return;
            }
            result = num1 / num2;
        }


        tvResult.setText("نتیجه: " + result);
    }
}
