package com.example.fullfeatureapp;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class BrowserActivity extends AppCompatActivity {

    WebView webView;
    Button backBtn, exitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        webView = findViewById(R.id.webView);
        backBtn = findViewById(R.id.backButton);
        exitBtn = findViewById(R.id.exitButton);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.google.com");

        backBtn.setOnClickListener(v -> finish());

        exitBtn.setOnClickListener(v -> {
            finishAffinity();  // بستن کل برنامه
            System.exit(0);
        });
    }
}
