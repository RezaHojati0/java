package com.example.fullfeatureapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.VideoView;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fullfeatureapp.MainActivity;

public class MediaActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    VideoView videoView;
    Button btnPlayMusic, btnStopMusic, btnPlayVideo, btnStopVideo, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);


        btnPlayMusic = findViewById(R.id.btnPlayMusic);
        btnStopMusic = findViewById(R.id.btnStopMusic);
        btnPlayVideo = findViewById(R.id.btnPlayVideo);
        btnStopVideo = findViewById(R.id.btnStopVideo);
        btnBack = findViewById(R.id.btnBack);
        videoView = findViewById(R.id.videoView);


        mediaPlayer = MediaPlayer.create(this, R.raw.music_file);


        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.sample_video);
        videoView.setVideoURI(videoUri);


        btnPlayMusic.setOnClickListener(v -> {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
        });



        btnStopMusic.setOnClickListener(v -> {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                mediaPlayer.seekTo(0);
            }
        });


        btnPlayVideo.setOnClickListener(v -> videoView.start());


        btnStopVideo.setOnClickListener(v -> {
            if (videoView.isPlaying()) {
                videoView.pause();
                videoView.seekTo(0);
            }
        });


        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(MediaActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
