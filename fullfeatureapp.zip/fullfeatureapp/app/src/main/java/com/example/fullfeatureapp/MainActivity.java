package com.example.fullfeatureapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.fullfeatureapp.adapter.ItemAdapter;
import com.example.fullfeatureapp.data.DatabaseHelper;
import com.example.fullfeatureapp.models.Item;
import java.util.ArrayList;
import android.widget.Button;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ItemAdapter adapter;
    private ArrayList<Item> items;
    private DatabaseHelper db;
    private SharedPreferences prefs;
    private Item selectedItem = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // welcome toast
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String user = prefs.getString("user", "Guest");
        Toast.makeText(this, "خوش آمدید, ", Toast.LENGTH_SHORT).show();

        // database
        db = new DatabaseHelper(this);
        items = new ArrayList<>();
        loadItems();

        listView = findViewById(R.id.listView);
        adapter = new ItemAdapter(this, items);
        listView.setAdapter(adapter);
        registerForContextMenu(listView);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            selectedItem = items.get(position);
            PopupMenu pop = new PopupMenu(MainActivity.this, view);
            pop.getMenuInflater().inflate(R.menu.menu_popup, pop.getMenu());

            pop.setOnMenuItemClickListener(mi -> {
                Item it = items.get(position);

                if (mi.getItemId() == R.id.action_details) {
                    Intent in = new Intent(MainActivity.this, DetailActivity.class);
                    in.putExtra("itemId", it.getId());         // ارسال ID
                    in.putExtra("itemName", it.getName());     // ارسال Name
                    startActivity(in);
                    return true;
                } else if (mi.getItemId() == R.id.action_browser) {
                    Intent browserIntent = new Intent(MainActivity.this, BrowserActivity.class);
                    startActivity(browserIntent);
                    return true;

                } else if (mi.getItemId() == R.id.action_edit) {
                    Item item = items.get(position);

                    EditText input = new EditText(MainActivity.this);
                    input.setText(item.getName());

                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("ویرایش آیتم")
                            .setView(input)
                            .setPositiveButton("تأیید", (dialog, which) -> {
                                String newName = input.getText().toString();
                                db.updateItem(item.getId(), newName);
                                loadItems();
                                adapter.notifyDataSetChanged();
                            })
                            .setNegativeButton("لغو", null)
                            .show();

                    return true;
                } else if (mi.getItemId() == R.id.action_delete) {
                    Item item = items.get(position);

                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("حذف آیتم")
                            .setMessage("آیا مطمئنی که می‌خواهی حذف شود؟")
                            .setPositiveButton("بله", (dialog, which) -> {
                                db.deleteItem(item.getId());
                                loadItems();
                                adapter.notifyDataSetChanged();
                            })
                            .setNegativeButton("خیر", null)
                            .show();

                    return true;
                } else if (mi.getItemId() == R.id.action_browser) {
                    // 5 آیتم اول لینک مخصوص - بقیه آیتم‌ها لینک عمومی گوگل
                    String query;
                    switch (position) {
                        case 0:
                            query = "https://www.google.com/search?q=آب";
                            break;
                        case 1:
                            query = "https://www.google.com/search?q=سخت افزار";
                            break;
                        case 2:
                            query = "https://www.google.com/search?q=جاوا";
                            break;
                        case 3:
                            query = "https://www.google.com/search?q=موبایل";
                            break;
                        case 4:
                            query = "https://www.google.com/search?q=لپ تاپ";
                            break;
                        default:
                            query = "https://www.google.com";
                    }

                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(query));
                    startActivity(browserIntent);
                    return true;
                }

                return false;
            });

            pop.show();
        });
        Button btnBack = findViewById(R.id.btnBack);
        Button btnExit = findViewById(R.id.btnExit);

        btnBack.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        btnExit.setOnClickListener(v -> {

            finishAffinity();
        });

    }

    private void loadItems() {
        Cursor c = db.getAllItems();
        if (c != null && c.moveToFirst()) {
            do {
                int id = c.getInt(c.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
                String name = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_NAME));
                items.add(new Item(id, name));
            } while (c.moveToNext());
            c.close();
        }
        if (items.isEmpty()) {
            for (int i = 1; i <= 10; i++) db.insertItem("Item " + i);
            loadItems();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_toast) {
            Toast.makeText(this, "گزینه پیام انتخاب شد", Toast.LENGTH_SHORT).show();
            return true;

        } else if (id == R.id.action_add) {
            int nextId = 1;
            if (!items.isEmpty()) {
                int maxId = 0;
                for (Item it : items) {
                    if (it.getId() > maxId) {
                        maxId = it.getId();
                    }
                }
                nextId = maxId + 1;
            }

            String newItemName = "Item " + nextId;
            db.insertItem(newItemName);
            loadItems();
            adapter.notifyDataSetChanged();
            return true;

        } else if (id == R.id.action_logout) {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;

        } else {
            return super.onOptionsItemSelected(item);
        }




    }




    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo info) {
        super.onCreateContextMenu(menu, v, info);
        getMenuInflater().inflate(R.menu.main_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Toast.makeText(this, "Context: " + item.getTitle(), Toast.LENGTH_SHORT).show();
        return true;
    }
    @Override
    protected void onResume() {
        super.onResume();
        // هر بار که برمی‌گردیم، لیست خالی و مجدداً بارگذاری کن
        items.clear();
        loadItems();
        adapter.notifyDataSetChanged();
    }

}