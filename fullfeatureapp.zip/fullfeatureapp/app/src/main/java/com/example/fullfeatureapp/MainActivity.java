package com.example.fullfeatureapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.fullfeatureapp.adapter.ItemAdapter;
import com.example.fullfeatureapp.data.DatabaseHelper;
import com.example.fullfeatureapp.models.Item;
import java.util.ArrayList;
import android.widget.Button;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;
import android.media.MediaPlayer;
import android.widget.VideoView;
import android.widget.ImageView;



public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ItemAdapter adapter;
    private ArrayList<Item> items;
    private DatabaseHelper db;
    private SharedPreferences prefs;
    private Item selectedItem = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String user = prefs.getString("user", "Guest");
        Toast.makeText(this, "خوش آمدید, ", Toast.LENGTH_SHORT).show();


        db = new DatabaseHelper(this);
        items = new ArrayList<>();
        loadItems();

        listView = findViewById(R.id.listView);
        adapter = new ItemAdapter(this, items);
        listView.setAdapter(adapter);
        registerForContextMenu(listView);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            selectedItem = items.get(position);
            PopupMenu pop = new PopupMenu(MainActivity.this, view);
            pop.getMenuInflater().inflate(R.menu.menu_popup, pop.getMenu());

            pop.setOnMenuItemClickListener(mi -> {
                int menuId = mi.getItemId();

                if (menuId == R.id.action_details) {
                    Intent in = new Intent(MainActivity.this, DetailActivity.class);
                    in.putExtra("itemId", selectedItem.getId());
                    in.putExtra("itemName", selectedItem.getName());
                    startActivity(in);
                    return true;

                } else if (menuId == R.id.action_browser) {

                    String keyword;
                    switch (position) {
                        case 0: keyword = "آب"; break;
                        case 1: keyword = "هوا"; break;
                        case 2: keyword = "جاوا"; break;
                        case 3: keyword = "گیاه"; break;
                        case 4: keyword = "لپ تاپ"; break;
                        default: keyword = selectedItem.getName();
                    }
                    String url = "https://www.google.com/search?q=" + Uri.encode(keyword);

                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(browserIntent);
                    return true;

                } else if (menuId == R.id.action_edit) {

                    return true;

                } else if (menuId == R.id.action_delete) {

                    return true;
                }

                return false;
            });

            pop.show();
        });

        Button btnBack = findViewById(R.id.btnBack);
        Button btnExit = findViewById(R.id.btnExit);

        btnBack.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        btnExit.setOnClickListener(v -> {

            finishAffinity();
        });

    }

    private void loadItems() {
        Cursor c = db.getAllItems();
        if (c != null && c.moveToFirst()) {
            do {
                int id = c.getInt(c.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
                String name = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_NAME));
                items.add(new Item(id, name));
            } while (c.moveToNext());
            c.close();
        }
        if (items.isEmpty()) {
            for (int i = 1; i <= 10; i++) db.insertItem("Item " + i);
            loadItems();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    MediaPlayer mediaPlayer;
    boolean isMusicPlaying = false;
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();



        if (id == R.id.menu_show_image) {
            ImageView imageView = findViewById(R.id.imageView);
            imageView.setVisibility(View.VISIBLE);
            imageView.setImageResource(R.drawable.sample_image);
            return true;
        }

        if (id == R.id.menu_play_music) {
            if (mediaPlayer == null) {
                Intent intent = new Intent(MainActivity.this, MediaActivity.class);
                startActivity(intent);

            }


        }

        if (id == R.id.menu_play_video) {
            Intent intent = new Intent(MainActivity.this, MediaActivity.class);
            startActivity(intent);

        }


        if (id == R.id.action_toast) {
            Toast.makeText(this, "گزینه پیام انتخاب شد", Toast.LENGTH_SHORT).show();
            return true;


        } else if (id == R.id.action_add) {

            int nextId = 1;
            for (Item it : items) {
                if (it.getId() >= nextId) {
                    nextId = it.getId() + 1;
                }
            }
            String newItemName = "Item " + nextId;


            db.insertItem(newItemName);
            items.add(new Item(nextId, newItemName));
            adapter.notifyDataSetChanged();

            Toast.makeText(this, "آیتم جدید اضافه شد: " + newItemName, Toast.LENGTH_SHORT).show();
            return true;


        } else if (id == R.id.action_edit) {
            if (selectedItem != null) {
                final EditText input = new EditText(this);
                input.setText(selectedItem.getName());

                new AlertDialog.Builder(this)
                        .setTitle("ویرایش آیتم")
                        .setView(input)
                        .setPositiveButton("ثبت", (dialog, which) -> {
                            String newName = input.getText().toString().trim();
                            if (newName.isEmpty()) {
                                Toast.makeText(this, "نام نمی‌تواند خالی باشد", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            db.updateItem(selectedItem.getId(), newName);
                            for (int i = 0; i < items.size(); i++) {
                                if (items.get(i).getId() == selectedItem.getId()) {
                                    items.set(i, new Item(selectedItem.getId(), newName));
                                    break;
                                }
                            }
                            adapter.notifyDataSetChanged();
                            Toast.makeText(this, "ویرایش با موفقیت انجام شد", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("لغو", null)
                        .show();
            } else {
                Toast.makeText(this, "لطفاً یک آیتم از لیست انتخاب کنید", Toast.LENGTH_SHORT).show();
            }
            return true;


        } else if (id == R.id.action_delete) {
            if (selectedItem != null) {
                new AlertDialog.Builder(this)
                        .setTitle("حذف آیتم")
                        .setMessage("آیا مطمئن هستید؟")
                        .setPositiveButton("بله", (dialog, which) -> {
                            db.deleteItem(selectedItem.getId());
                            for (int i = 0; i < items.size(); i++) {
                                if (items.get(i).getId() == selectedItem.getId()) {
                                    items.remove(i);
                                    break;
                                }
                            }
                            selectedItem = null;
                            adapter.notifyDataSetChanged();
                            Toast.makeText(this, "حذف با موفقیت انجام شد", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("خیر", null)
                        .show();
            } else {
                Toast.makeText(this, "لطفاً یک آیتم از لیست انتخاب کنید", Toast.LENGTH_SHORT).show();
            }
            return true;


        } else if (id == R.id.action_logout) {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }






    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo info) {
        super.onCreateContextMenu(menu, v, info);
        getMenuInflater().inflate(R.menu.main_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Toast.makeText(this, "Context: " + item.getTitle(), Toast.LENGTH_SHORT).show();
        return true;
    }
    @Override
    protected void onResume() {
        super.onResume();

        items.clear();
        loadItems();
        adapter.notifyDataSetChanged();
    }

}