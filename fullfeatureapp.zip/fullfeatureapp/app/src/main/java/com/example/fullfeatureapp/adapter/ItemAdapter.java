package com.example.fullfeatureapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.fullfeatureapp.R;
import com.example.fullfeatureapp.models.Item;

import java.util.List;

public class ItemAdapter extends BaseAdapter {
    private Context ctx;
    private List<Item> list;
    private LayoutInflater inflater;
    public ItemAdapter(Context ctx, List<Item> list) {
        this.ctx = ctx; this.list = list;
        this.inflater = LayoutInflater.from(ctx);
    }
    @Override public int getCount() { return list.size(); }
    @Override public Object getItem(int pos) { return list.get(pos); }
    @Override public long getItemId(int pos) { return list.get(pos).getId(); }
    @Override
    public View getView(int pos, View cv, ViewGroup parent) {
        ViewHolder vh;
        if (cv == null) {
            cv = inflater.inflate(R.layout.list_item, parent, false);
            vh = new ViewHolder();
            vh.tvName = cv.findViewById(R.id.tvName);
            cv.setTag(vh);
        } else vh = (ViewHolder) cv.getTag();
        vh.tvName.setText(list.get(pos).getName());
        return cv;
    }
    static class ViewHolder { TextView tvName; }
}