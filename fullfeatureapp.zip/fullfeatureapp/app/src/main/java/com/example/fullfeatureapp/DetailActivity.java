package com.example.fullfeatureapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // دریافت ID و Name با همان کلیدها
        int id = getIntent().getIntExtra("itemId", -1);
        String name = getIntent().getStringExtra("itemName");

        TextView txt = findViewById(R.id.detailsText);
        txt.setText("ID: " + id + "\nName: " + name);
    }

}