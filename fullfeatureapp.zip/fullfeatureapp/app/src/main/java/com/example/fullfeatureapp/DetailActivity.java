package com.example.fullfeatureapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fullfeatureapp.data.DatabaseHelper;

public class DetailActivity extends AppCompatActivity {
    private int itemId;
    private String itemName;
    private TextView txtItemName;
    private Button btnEdit, btnDelete,btnback;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // init
        txtItemName = findViewById(R.id.txtItemName);
        btnEdit     = findViewById(R.id.btnEdit);
        btnDelete   = findViewById(R.id.btnDelete);
        btnback = findViewById(R.id.btnBack);
        db          = new DatabaseHelper(this);


        // دریافت داده‌ها
        itemId   = getIntent().getIntExtra("itemId", -1);
        itemName = getIntent().getStringExtra("itemName");
        txtItemName.setText(itemName);

        // ویرایش
        btnEdit.setOnClickListener(v -> {
            final EditText input = new EditText(this);
            input.setText(itemName);

            new AlertDialog.Builder(this)
                    .setTitle("ویرایش آیتم")
                    .setView(input)
                    .setPositiveButton("ذخیره", (dialog, which) -> {
                        String newName = input.getText().toString().trim();
                        if (newName.isEmpty()) {
                            Toast.makeText(this, "نام نمی‌تواند خالی باشد", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        boolean ok = db.updateItem(itemId, newName);
                        if (ok) {
                            txtItemName.setText(newName);
                            Toast.makeText(this, "ویرایش با موفقیت انجام شد", Toast.LENGTH_SHORT).show();
                        }
                         else {
                            Toast.makeText(this, "خطا در ویرایش", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("لغو", null)
                    .show();
        });

        // حذف
        btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("حذف آیتم")
                    .setMessage("آیا مطمئنید می‌خواهید این آیتم حذف شود؟")
                    .setPositiveButton("حذف", (dialog, which) -> {
                        boolean ok = db.deleteItem(itemId);
                        if (ok) {
                            Toast.makeText(this, "حذف با موفقیت انجام شد", Toast.LENGTH_SHORT).show();
                            finish(); // با finish برمی‌گردیم به MainActivity و آنجا onResume لیست رو رفرش می‌کنه
                        } else {
                            Toast.makeText(this, "خطا در حذف", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("لغو", null)
                    .show();
        });
        btnback.setOnClickListener(v ->{
            Intent intent=new Intent(DetailActivity.this,MainActivity.class);
            startActivity(intent);
            finish();
        } );

    }
}
