package com.example.fullfeatureapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText etUser, etPass;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        etUser.setText(prefs.getString("user", ""));
        etPass.setText(prefs.getString("pass", ""));

        Button btn = findViewById(R.id.btnLogin);
        btn.setOnClickListener(v -> {
            String username = etUser.getText().toString().trim();
            String password = etPass.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "نام کاربری و رمز عبور را وارد کنید", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences userPrefs = getSharedPreferences("UsersPrefs", MODE_PRIVATE);
            SharedPreferences loginPrefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE); // برای ذخیره‌ی کاربر فعلی

            if (!userPrefs.contains(username)) {
                // نام کاربری جدید - ذخیره شود
                userPrefs.edit().putString(username, password).apply();

                // ذخیره کاربر فعلی برای نمایش یا استفاده‌های دیگر
                loginPrefs.edit().putString("currentUser", username).apply();

                Toast.makeText(this, "ثبت‌نام و ورود موفق: " + username, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                // نام کاربری وجود دارد - بررسی رمز
                String savedPassword = userPrefs.getString(username, "");

                if (savedPassword.equals(password)) {
                    loginPrefs.edit().putString("currentUser", username).apply(); // ذخیره کاربر فعلی
                    Toast.makeText(this, "ورود موفق: " + username, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "رمز عبور اشتباه است برای کاربر: " + username, Toast.LENGTH_SHORT).show();
                }
            }
        });



        Button btnExit = findViewById(R.id.btnExit);



        btnExit.setOnClickListener(v -> {

            finishAffinity();
        });

    }
}