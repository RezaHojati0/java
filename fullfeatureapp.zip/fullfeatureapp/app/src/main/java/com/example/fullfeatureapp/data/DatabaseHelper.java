package com.example.fullfeatureapp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "items.db";
    private static final int DB_VERSION = 1;
    public static final String TABLE = "items";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";

    public DatabaseHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_NAME + " TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }
    public boolean insertItem(String name) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        return db.insert(TABLE, null, cv) != -1;
    }
    // حذف
    // در DatabaseHelper.java

    // در DatabaseHelper.java

    public boolean updateItem(int id, String newName) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, newName);
        int rows = db.update(TABLE, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE, COL_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }



    public Cursor getAllItems() {
        return getReadableDatabase().query(TABLE, new String[]{COL_ID, COL_NAME}, null, null, null, null, COL_ID + " ASC");
    }
}